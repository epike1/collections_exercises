package exampleClasses;

public class StoreItem {

    private String name;
    private double cost;

    public StoreItem(String name, double cost) {

    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
